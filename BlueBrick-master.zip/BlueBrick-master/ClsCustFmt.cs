
namespace BlueBrick
{
    public class ClsCustFmt
    {
        // for drawing format changer. not implemented yet.
        
        //detect sheet format
        //  if same, reload
        //  else load new
        //update drafting standard
        //add missing layers
        //cycle annotations:
        //  update table templates
        //      ¿store cell data in array
        //      ¿delete table?
        //      ¿add new table with proper template?
        //      ¿add cell data back in?
        //  shift annotations to proper layers
        //  ¿check for line colors? 
        //remove unused layers
    }
}